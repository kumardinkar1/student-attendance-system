document.getElementById('attendanceForm').addEventListener('submit', function(e) {
    e.preventDefault();
  
    var studentName = document.getElementById('studentName').value;
    var rollNumber = document.getElementById('rollNumber').value;
    var date = document.getElementById('date').value;
    var attendanceStatus = document.getElementById('attendanceStatus').value;
    var courseStatus = document.getElementById('courseStatus').value;
  
    var newRow = document.createElement('tr');
    newRow.innerHTML = '<td>' + studentName + '</td><td>' + rollNumber + '</td><td>' + courseStatus + '</td><td>' + date + '</td><td>' + attendanceStatus + '</td>';
  
    document.getElementById('attendanceTable').appendChild(newRow);
  
    // Reset the form
    document.getElementById('attendanceForm').reset();
  });
  