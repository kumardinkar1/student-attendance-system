document.getElementById("loginForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent form submission
    
    // Get the values from the input fields
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    
    // Perform login validation (you can replace this with your own logic)
    if (username === "admin" && password === "password") {
      alert("Login successful!");
      // Redirect to a different page or perform other actions
    } else {
      alert("Invalid username or password. Please try again.");
    }
  });
  